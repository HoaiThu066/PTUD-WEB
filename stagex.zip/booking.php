<?php 
require 'includes/header.php';
echo '<div class="row g-4" style="margin-top: 80px;"><aside class="col-lg-3 col-md-4"><div class="card h-100"><div class="card-header text-white fw-bold">Danh mục Thể loại</div><div class="card-body" id="menuArea">';
include 'includes/menu.php';
echo '</div></div></aside><section class="col-lg-9 col-md-8"><div class="card h-100"><div class="card-header text-white fw-bold">Danh sách Vở diễn</div><div class="card-body" id="contentArea">';
include 'includes/content.php';
echo '</div></div></section></div>';
require 'includes/footer.php';
?>