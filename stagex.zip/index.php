<?php
require 'includes/header.php';
require_once 'includes/db_connect.php';
require 'includes/footer.php';

$shows = $mysqli->query("SELECT s.*, GROUP_CONCAT(g.genre_name SEPARATOR ', ') as genres 
                         FROM shows s 
                         LEFT JOIN show_genres sg ON s.show_id = sg.show_id 
                         LEFT JOIN genres g ON sg.genre_id = g.genre_id 
                         GROUP BY s.show_id 
                         ORDER BY s.created_at DESC")->fetch_all(MYSQLI_ASSOC);

$featured = $mysqli->query("SELECT DISTINCT s.*, GROUP_CONCAT(g.genre_name SEPARATOR ', ') as genres 
                            FROM shows s 
                            JOIN performances p ON s.show_id = p.show_id 
                            LEFT JOIN show_genres sg ON s.show_id = sg.show_id 
                            LEFT JOIN genres g ON sg.genre_id = g.genre_id 
                            WHERE p.performance_date >= CURDATE() 
                            GROUP BY s.show_id 
                            ORDER BY p.performance_date ASC 
                            LIMIT 6")->fetch_all(MYSQLI_ASSOC);
?>

<div id="heroCarousel" class="carousel slide full-bleed mb-5" data-bs-ride="carousel">
    <div class="carousel-indicators">
        <?php foreach ($shows as $index => $show): ?>
            <button type="button" data-bs-target="#heroCarousel" data-bs-slide-to="<?= $index ?>" 
                    class="<?= $index === 0 ? 'active' : '' ?>" 
                    aria-label="Slide <?= $index + 1 ?>"></button>
        <?php endforeach; ?>
    </div>
    <div class="carousel-inner">
        <?php foreach ($shows as $index => $show): ?>
            <div class="carousel-item <?= $index === 0 ? 'active' : '' ?>">
                <div class="carousel-slide-wrapper">
                    <img src="<?= htmlspecialchars($show['poster_image_url']) ?>" 
                         class="d-block w-100 carousel-image" 
                         alt="<?= htmlspecialchars($show['title']) ?>">
                    <div class="carousel-overlay"></div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
    
    <button class="carousel-control-prev" type="button" data-bs-target="#heroCarousel" data-bs-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Previous</span>
    </button>
    <button class="carousel-control-next" type="button" data-bs-target="#heroCarousel" data-bs-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Next</span>
    </button>
</div>
<?php require 'includes/footer.php'; ?>