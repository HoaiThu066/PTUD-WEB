document.addEventListener('click', function(e) {
    const a = e.target.closest('a');
    if (!a) return;

    // Handle clicks on performance links to show the seat map
    if (a.dataset.action === 'viewPerf') {
        e.preventDefault();
        const perfId = a.dataset.perfId;
        fetch(`api/data.php?action=get_performance_details&id=${perfId}`)
            .then(res => res.json())
            .then(data => {
                if (data.ok) renderSeatMap(data.data);
            });
    } 
    // Handle clicks on genre filter links
    else if (window.location.pathname.includes('booking.php') && a.href.includes('booking.php')) {
        e.preventDefault();
        const url = new URL(a.href);
        const contentUrl = 'includes/content.php' + url.search;
        fetch(contentUrl).then(res => res.text()).then(html => { 
            document.getElementById('contentArea').innerHTML = html; 
        });
    }
});

function renderSeatMap(data) {
    const { theater, seats, booked_seat_ids } = data;
    const rows = [...new Set(seats.map(s => s.row_char))].sort();

    const mapHtml = `
        <h4 class="mt-4 text-white">Sơ đồ phòng: ${theater.name}</h4>
        <div class="p-3 border rounded" style="background:var(--bg);">
            <div class="screen">SÂN KHẤU</div>
            ${rows.map(row => `
                <div class="seat-row">
                    ${seats.filter(s => s.row_char === row).sort((a,b) => a.seat_number - b.seat_number).map(seat => `
                        <div class="seat ${seat.color_class} ${booked_seat_ids.includes(seat.seat_id) ? 'booked' : ''}" title="${seat.row_char}${seat.seat_number}">
                            ${seat.row_char}${seat.seat_number}
                        </div>
                    `).join('')}
                </div>
            `).join('')}
        </div>`;
    
    const container = document.getElementById('seat-map-container');
    if (container) {
        container.innerHTML = mapHtml;
        window.scrollTo({ top: container.offsetTop - 100, behavior: 'smooth' });
    }
}