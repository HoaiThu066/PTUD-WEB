const $ = (sel) => document.querySelector(sel);
const API_URL = '../api/data.php';

async function loadAllData() {
    try {
        const [genresRes, showsRes, perfsRes, theatersRes] = await Promise.all([
            fetch(`${API_URL}?action=list_genres`),
            fetch(`${API_URL}?action=list_shows`),
            fetch(`${API_URL}?action=list_performances`),
            fetch(`${API_URL}?action=list_theaters`)
        ]);
        const genres = await genresRes.json();
        const shows = await showsRes.json();
        const perfs = await perfsRes.json();
        const theaters = await theatersRes.json();

        // Populate Genres Checkboxes (Vở & Suất Diễn Tab)
        if (document.getElementById('genre_checkboxes')) {
            $('#genre_checkboxes').innerHTML = (genres.data || []).map(g => `<div class="form-check"><input class="form-check-input" type="checkbox" name="genre_ids[]" value="${g.genre_id}" id="genre_${g.genre_id}"><label class="form-check-label" for="genre_${g.genre_id}">${g.genre_name}</label></div>`).join('');
        }

        // Populate Shows Table and Selects (Vở & Suất Diễn Tab)
        if (document.getElementById('tableShows')) {
            $('#tableShows tbody').innerHTML = (shows.data || []).map(s => `<tr><td>${s.title}</td><td>${(s.genres || []).map(g => g.genre_name).join(', ')}</td><td>${s.duration_minutes}</td><td class="text-end"><button class="btn btn-sm btn-outline-light" onclick='fillShow(${JSON.stringify(s)})'>Sửa</button> <button class="btn btn-sm btn-outline-danger" onclick="deleteItem('show', ${s.show_id})">Xóa</button></td></tr>`).join('') || '<tr><td colspan="4">Chưa có</td></tr>';
            $('#perf_show_select').innerHTML = (shows.data || []).map(s => `<option value="${s.show_id}">${s.title}</option>`).join('');
        }

        // Populate Theaters List and Select (Both Tabs)
        if (document.getElementById('theaterList')) {
            $('#theaterList').innerHTML = (theaters.data || []).map(t => `<div class="d-flex justify-content-between align-items-center border-bottom py-2"><span>${t.name}</span><button class="btn btn-sm btn-outline-primary" onclick="openSeatEditor(${t.theater_id})">Sửa sơ đồ</button></div>`).join('') || '<div class="small text-dark">Chưa có phòng nào.</div>';
        }
        if (document.getElementById('perf_theater_select')) {
             $('#perf_theater_select').innerHTML = (theaters.data || []).map(t => `<option value="${t.theater_id}">${t.name}</option>`).join('');
        }
       
        // Populate Performances Table (Vở & Suất Diễn Tab)
        if (document.getElementById('tablePerfs')) {
            const showMap = new Map((shows.data || []).map(s => [s.show_id, s.title]));
            const theaterMap = new Map((theaters.data || []).map(t => [t.theater_id, t.name]));
            $('#tablePerfs tbody').innerHTML = (perfs.data || []).map(p => `<tr><td>${p.performance_id}</td><td>${showMap.get(p.show_id) || '?'}</td><td>${theaterMap.get(p.theater_id) || '?'}</td><td>${p.performance_date} ${p.start_time}</td><td>${Number(p.price).toLocaleString('vi-VN')} VND</td><td class="text-end"><button class="btn btn-sm btn-outline-danger" onclick="deleteItem('performance', ${p.performance_id})">Xóa</button></td></tr>`).join('') || '<tr><td colspan="6">Chưa có</td></tr>';
        }

        // Populate Genres Table (Thể loại Tab)
        if (document.getElementById('tableGenres')) {
            $('#tableGenres tbody').innerHTML = (genres.data || []).map(g => `<tr><td>${g.genre_name}</td><td class="text-end"><button class="btn btn-sm btn-outline-light" onclick='fillGenre(${JSON.stringify(g)})'>Sửa</button> <button class="btn btn-sm btn-outline-danger" onclick="deleteItem('genre', ${g.genre_id})">Xóa</button></td></tr>`).join('') || '<tr><td colspan="2">Chưa có</td></tr>';
        }

    } catch (error) { console.error("Failed to load data:", error); }
}

function fillShow(s) {
    $('#show_id').value = s.show_id; $('#title').value = s.title || '';
    document.querySelectorAll('input[name="genre_ids[]"]').forEach(checkbox => { checkbox.checked = (s.genres || []).some(g => g.genre_id == checkbox.value); });
    $('#duration_minutes').value = s.duration_minutes || ''; $('#director').value = s.director || '';
    $('#poster_image_url').value = s.poster_image_url || ''; $('#description').value = s.description || '';
}

function fillGenre(g) {
    $('#genre_id').value = g.genre_id;
    $('#genre_name').value = g.genre_name || '';
}

async function handleFormSubmit(url, payload, form) {
    const res = await fetch(url, { method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify(payload) });
    if (res.ok) { form.reset(); if (form.querySelector('input[type="hidden"]')) { form.querySelector('input[type="hidden"]').value = ''; } loadAllData(); } 
    else { alert('Lỗi! Không thể lưu dữ liệu.'); }
}

if (document.getElementById('showForm')) {
    $('#showForm').addEventListener('submit', e => { e.preventDefault(); const payload = { show_id: $('#show_id').value, title: $('#title').value, genre_ids: Array.from(document.querySelectorAll('input[name="genre_ids[]"]:checked')).map(cb => cb.value), duration_minutes: $('#duration_minutes').value, director: $('#director').value, poster_image_url: $('#poster_image_url').value, description: $('#description').value }; handleFormSubmit(`${API_URL}?action=save_show`, payload, e.target); });
}
if (document.getElementById('perfForm')) {
    $('#perfForm').addEventListener('submit', e => { e.preventDefault(); const payload = { show_id: $('#perf_show_select').value, theater_id: $('#perf_theater_select').value, performance_date: $('#performance_date').value, start_time: $('#start_time').value, price: $('#price').value }; handleFormSubmit(`${API_URL}?action=save_performance`, payload, e.target); });
}
if (document.getElementById('genreForm')) {
    $('#genreForm').addEventListener('submit', e => { 
        e.preventDefault(); 
        const payload = { genre_id: $('#genre_id').value, genre_name: $('#genre_name').value }; 
        handleFormSubmit(`${API_URL}?action=save_genre`, payload, e.target); 
    });
}

async function deleteItem(type, id) {
    if (!confirm('Bạn có chắc chắn muốn xóa mục này?')) return;
    const payload = {}; payload[type + '_id'] = id;
    await fetch(`${API_URL}?action=delete_${type}`, { method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify(payload) });
    loadAllData();
}

async function openSeatEditor(theaterId) {
    try {
        const res = await fetch(`${API_URL}?action=get_seat_map&id=${theaterId}`);
        const data = await res.json();
        if (!data.ok) throw new Error(data.error || 'Failed to fetch seat map');
        
        const { theater, seats } = data.data;
        $('#editingTheaterName').textContent = theater.name;
        const rows = [...new Set(seats.map(s => s.row_char))].sort();
        $('#seatEditor').innerHTML = `<div class="screen">SÂN KHẤU</div>` + rows.map(row => 
            `<div class="seat-row">` + seats.filter(s => s.row_char === row).sort((a,b) => a.seat_number - b.seat_number).map(seat => 
                `<div class="seat admin-seat ${seat.color_class}" data-seat-id="${seat.seat_id}" onclick="cycleCategory(${seat.seat_id}, ${theaterId})">${seat.row_char}${seat.seat_number}</div>`
            ).join('') + `</div>`
        ).join('');
    } catch(error) {
        console.error("Error opening seat editor:", error);
        $('#seatEditor').innerHTML = '<div class="alert alert-danger">Không thể tải sơ đồ ghế.</div>';
    }
}

async function cycleCategory(seatId, theaterId) {
    const seatElement = document.querySelector(`.seat.admin-seat[data-seat-id="${seatId}"]`);
    if (seatElement) {
        let currentClass = seatElement.className.match(/A|B|C/)?.[0] || 'A';
        let nextClass = currentClass === 'A' ? 'B' : currentClass === 'B' ? 'C' : 'A';
        seatElement.className = seatElement.className.replace(/A|B|C/, nextClass);
    }
    await fetch(`${API_URL}?action=update_seat_category`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ seat_id: seatId }) });
}

async function confirmSeatEdits(theaterId) {
    // Logic để xác nhận và lưu toàn bộ thay đổi (nếu cần thêm API riêng, hãy mở rộng)
    alert('Chỉnh sửa đã được xác nhận và lưu thành công!');
    loadAllData(); // Reload dữ liệu để cập nhật giao diện
}

$('#theaterForm').addEventListener('submit', async e => {
    e.preventDefault();
    const payload = { name: $('#theaterName').value, rows: $('#rows').value, cols: $('#cols').value };
    await handleFormSubmit(`${API_URL}?action=create_theater`, payload, e.target);
});

document.getElementById('confirmEditButton')?.addEventListener('click', () => {
    const theaterId = document.querySelector('#editingTheaterName')?.textContent ? document.querySelectorAll('#theaterList button').find(btn => btn.textContent.includes(document.querySelector('#editingTheaterName').textContent.split(' ')[0])).getAttribute('onclick').match(/\d+/)[0] : null;
    if (theaterId) confirmSeatEdits(theaterId);
});

document.addEventListener('DOMContentLoaded', loadAllData);