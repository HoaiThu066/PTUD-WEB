</main>
    <footer class="container text-center py-4 mt-auto">
      <p class="text-muted">&copy; 2025 StageX. All rights reserved.</p>
    </footer>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="/assets/js/booking.js"></script>
</body>
</html>
