<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>StageX</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css">
    <link href="/assets/css/style.css" rel="stylesheet">
</head>
<body class="bg-dark">
    <header class="navbar navbar-expand-lg fixed-top border-bottom border-secondary-subtle">
        <div class="container">
            <a class="navbar-brand text-warning fw-bold" href="index.php"><i class="bi bi-ticket-detailed"></i> StageX</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="offcanvas offcanvas-end text-bg-dark" id="offcanvasNav">
                <div class="offcanvas-body">
                    <ul class="navbar-nav justify-content-end flex-grow-1 mt-3 me-2">
                        <li class="nav-item">
                            <a class="nav-link-btn btn btn-warning text-dark fw-bold" href="booking.php">
                                <i class="bi bi-calendar2-week"></i> Đặt Mua Vé
                            </a>
                        </li>
                    </ul>
                    <form class="d-flex mt-3" role="search" action="/booking.php" method="get">
                        <input type="hidden" name="type" value="search">
                        <input class="form-control me-2" type="search" name="q" placeholder="Tìm kiếm ..." aria-label="Search">
                        <button class="btn btn-outline-warning" type="submit"><i class="bi bi-search"></i></button>
                    </form>
                </div>
            </div>
        </div>
    </header>
    <main class="container py-10">