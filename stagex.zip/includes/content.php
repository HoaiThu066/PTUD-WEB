<?php
require_once __DIR__ . "/db_connect.php";

$type = $_GET["type"] ?? null; 
$id = isset($_GET["id"]) ? intval($_GET["id"]) : null;

function render_show_card($show_data, $db_connection) {
    $genre_stmt = $db_connection->prepare("SELECT g.genre_name FROM show_genres sg JOIN genres g ON sg.genre_id = g.genre_id WHERE sg.show_id = ?");
    $genre_stmt->bind_param("i", $show_data['show_id']);
    $genre_stmt->execute();
    $genres = $genre_stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $genre_names = !empty($genres) ? implode(', ', array_column($genres, 'genre_name')) : 'Chưa phân loại';

    return '
    <div class="col-sm-6 col-lg-4 mb-3">
        <div class="card h-100">
            <img src="' . htmlspecialchars($show_data["poster_image_url"]) . '" class="card-img-top poster" alt="Poster">
            <div class="card-body d-flex flex-column">
                <h5 class="card-title">' . htmlspecialchars($show_data['title']) . '</h5>
                <p class="text-muted small">' . htmlspecialchars($genre_names) . '</p>
                <p class="card-text flex-grow-1">' . htmlspecialchars(substr($show_data["description"], 0, 80)) . '...</p>
                <a class="btn btn-outline-primary mt-auto" href="booking.php?type=show&id=' . $show_data['show_id'] . '">Xem các suất diễn</a>
            </div>
        </div>
    </div>';
}

if ($type === "show" && $id) {
    $show = $mysqli->query("SELECT * FROM shows WHERE show_id = $id")->fetch_assoc();
    $performances = $mysqli->query("SELECT * FROM performances WHERE show_id = $id AND performance_date >= CURDATE() ORDER BY performance_date, start_time")->fetch_all(MYSQLI_ASSOC);
    
    echo '<div><h3 class="text-white">' . htmlspecialchars($show["title"]) . '</h3><p>' . nl2br(htmlspecialchars($show["description"])) . '</p></div><h5 class="mt-4 text-white">Suất diễn sắp tới</h5>';
    
    if (empty($performances)) { 
        echo '<div class="alert alert-info">Chưa có lịch diễn cho vở kịch này.</div>'; 
    } else { 
        echo '<div class="list-group">'; 
        foreach ($performances as $p) { 
            echo '<a href="#" class="list-group-item list-group-item-action" data-action="viewPerf" data-perf-id="'.$p['performance_id'].'">
                <div class="d-flex w-100 justify-content-between">
                    <h6 class="mb-1">'.htmlspecialchars($p["performance_date"] . " lúc " . date("H:i", strtotime($p["start_time"]))).'</h6>
                    <small>Nhấn để xem sơ đồ</small>
                </div>
                <small class="text-muted">Giá vé từ '.number_format($p["price"], 0).' VND</small>
            </a>'; 
        } 
        echo '</div>'; 
    }
    echo '<div id="seat-map-container" class="mt-4"></div>';

} else {
    $query = "SELECT s.* FROM shows s ";
    if ($type === "genre" && $id) {
        $query .= " JOIN show_genres sg ON s.show_id = sg.show_id WHERE sg.genre_id = " . $id;
    }
    $query .= " ORDER BY s.title";
    $shows = $mysqli->query($query)->fetch_all(MYSQLI_ASSOC);

    echo '<div class="row g-3">'; 
    if (empty($shows)) { 
        echo '<div class="col-12"><div class="alert alert-secondary">Không tìm thấy vở diễn nào.</div></div>'; 
    } else { 
        foreach ($shows as $s) { 
            echo render_show_card($s, $mysqli); 
        } 
    }
    echo '</div>';
}
?>