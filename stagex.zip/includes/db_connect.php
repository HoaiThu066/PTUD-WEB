<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
$mysqli = new mysqli('localhost', 'root', '', 'stagex_db');
if ($mysqli->connect_error) { die("DB connection failed: " . $mysqli->connect_error); }
$mysqli->set_charset("utf8mb4");
?>