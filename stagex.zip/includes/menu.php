<?php
require_once __DIR__ . "/db_connect.php";
$genres = $mysqli->query("SELECT * FROM genres ORDER BY genre_name")->fetch_all(MYSQLI_ASSOC);
?>
<div class="list-group">
    <a href="booking.php" class="list-group-item list-group-item-action">Tất cả</a>
    <?php foreach ($genres as $g): ?>
        <a href="booking.php?type=genre&id=<?= intval($g['genre_id']) ?>" class="list-group-item list-group-item-action">
            <?= htmlspecialchars($g["genre_name"]) ?>
        </a>
    <?php endforeach; ?>
</div>