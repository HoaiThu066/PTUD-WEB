<!doctype html>
<html lang="vi">
<head>
    <meta charset="utf-8"><title>StageX - Admin</title><meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="../assets/css/style.css" rel="stylesheet">
</head>
<body class="bg-dark text-light">
    <header class="bg-black text-white py-3"><div class="container"><a href="index.php" class="navbar-brand fw-bold text-white">ADMIN - STAGEX</a></div></header>
    <main class="container py-4">
        <ul class="nav nav-pills mb-3" id="adminTabs">
            <li class="nav-item"><a class="nav-link active" data-bs-toggle="tab" href="#showsAndPerfs">Vở & Suất Diễn</a></li>
            <li class="nav-item"><a class="nav-link" data-bs-toggle="tab" href="#theaters">Rạp & Ghế</a></li>
            <li class="nav-item"><a class="nav-link" data-bs-toggle="tab" href="#genres">Thể loại</a></li>
        </ul>
        <div class="tab-content">
            <div class="tab-pane fade show active" id="showsAndPerfs">
                <div class="card bg-secondary-subtle text-dark p-3">
                    <div class="row g-4">
                        <div class="col-md-6"><h5 class="fw-bold">1. Quản lý Vở diễn</h5><form id="showForm" class="row g-2">
                            <input type="hidden" id="show_id" />
                            <div class="col-12"><label class="form-label">Tiêu đề</label><input class="form-control" id="title" placeholder="Tiêu đề" required></div>
                            <div class="col-12"><label class="form-label">Thể loại (chọn nhiều):</label><div id="genre_checkboxes" class="border rounded p-2 bg-white" style="height: 120px; overflow-y: auto;"></div></div>
                            <div class="col-6"><label class="form-label">Thời lượng (phút)</label><input class="form-control" id="duration_minutes" type="number" placeholder="Thời lượng (phút)"></div>
                            <div class="col-6"><label class="form-label">Đạo diễn</label><input class="form-control" id="director" placeholder="Đạo diễn"></div>
                            <div class="col-12"><label class="form-label">URL Poster</label><input class="form-control" id="poster_image_url" placeholder="URL Poster (vd: /images/poster.jpg)"></div>
                            <div class="col-12"><label class="form-label">Mô tả</label><textarea class="form-control" id="description" placeholder="Mô tả"></textarea></div>
                            <div class="col-12 d-grid"><button class="btn btn-primary">Lưu Vở diễn</button></div>
                        </form></div>
                        <div class="col-md-6"><h5 class="fw-bold">2. Quản lý Suất diễn</h5><form id="perfForm" class="row g-2">
                            <input type="hidden" id="performance_id" />
                            <div class="col-12"><label class="form-label">Vở diễn</label><select id="perf_show_select" class="form-select" required></select></div>
                            <div class="col-12"><label class="form-label">Phòng diễn</label><select id="perf_theater_select" class="form-select" required></select></div>
                            <div class="col-6"><label class="form-label">Ngày diễn</label><input class="form-control" id="performance_date" type="date" required></div>
                            <div class="col-6"><label class="form-label">Giờ bắt đầu</label><input class="form-control" id="start_time" type="time" required></div>
                            <div class="col-12"><label class="form-label">Giá vé (VND)</label><input class="form-control" id="price" type="number" step="1000" placeholder="Giá vé (VND)" required></div>
                            <div class="col-12 d-grid"><button class="btn btn-warning">Lưu Suất diễn</button></div>
                        </form></div>
                        <hr>
                        <div class="col-12"><h5 class="fw-bold">Bảng Vở diễn</h5><div class="table-responsive"><table class="table table-sm table-dark table-striped align-middle" id="tableShows"><thead><tr><th>Tựa</th><th>Thể loại</th><th>Phút</th><th></th></tr></thead><tbody></tbody></table></div></div>
                        <div class="col-12"><h5 class="fw-bold">Bảng Suất diễn</h5><div class="table-responsive"><table class="table table-sm table-dark table-striped align-middle" id="tablePerfs"><thead><tr><th>ID</th><th>Vở</th><th>Phòng</th><th>Ngày giờ</th><th>Giá</th><th></th></tr></thead><tbody></tbody></table></div></div>
                    </div>
                </div>
            </div>
            <div class="tab-pane fade" id="theaters">
                <div class="card bg-secondary-subtle text-dark p-3">
                    <div class="row g-3">
                        <div class="col-lg-4"><h5 class="fw-bold">1. Tạo phòng diễn</h5><form id="theaterForm" class="row g-2">
                            <div class="col-12"><label class="form-label">Tên phòng</label><input id="theaterName" class="form-control" placeholder="Tên phòng" required></div>
                            <div class="col-12"><label class="form-label">Số hàng (A, B..)</label><input id="rows" type="number" class="form-control" placeholder="Số hàng (A, B..)" value="8" min="1"></div>
                            <div class="col-12"><label class="form-label">Số ghế/hàng</label><input id="cols" type="number" class="form-control" placeholder="Số ghế/hàng" value="12" min="1"></div>
                            <div class="col-12 d-grid"><button class="btn btn-warning">Tạo sơ đồ</button></div>
                        </form><hr><h5 class="fw-bold">2. Chọn phòng để sửa</h5><div id="theaterList"></div></div>
                        <div class="col-lg-8"><h5 class="fw-bold">3. Sửa sơ đồ ghế (<span id="editingTheaterName" class="text-warning"></span>)</h5><div class="small mb-2">Click vào ghế để thay đổi hạng (A -> B -> C).</div><div id="seatEditor" class="p-2 border rounded bg-dark"></div><div class="mt-3"><button id="confirmEditButton" class="btn btn-success">Xác nhận chỉnh sửa</button></div></div>
                    </div>
                </div>
            </div>
            <div class="tab-pane fade" id="genres">
                <div class="card bg-secondary-subtle text-dark p-3">
                    <div class="row g-4">
                        <div class="col-md-6">
                            <h5 class="fw-bold">Quản lý Thể loại</h5>
                            <form id="genreForm" class="row g-2">
                                <input type="hidden" id="genre_id" />
                                <div class="col-12">
                                    <label class="form-label">Tên thể loại</label>
                                    <input class="form-control" id="genre_name" placeholder="Tên thể loại" required>
                                </div>
                                <div class="col-12 d-grid">
                                    <button class="btn btn-primary">Lưu Thể loại</button>
                                </div>
                            </form>
                        </div>
                        <div class="col-md-6">
                            <h5 class="fw-bold">Danh sách Thể loại</h5>
                            <div class="table-responsive">
                                <table class="table table-sm table-dark table-striped align-middle" id="tableGenres">
                                    <thead>
                                        <tr><th>Tên</th><th></th></tr>
                                    </thead>
                                    <tbody></tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
    <footer class="bg-black text-white text-center py-3 mt-4"><p>&copy; 2025 StageX</p></footer>
    <script src="../assets/js/staff.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>