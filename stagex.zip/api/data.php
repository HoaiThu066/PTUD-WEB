<?php
require_once __DIR__ . "/../includes/db_connect.php";
header("Content-Type: application/json; charset=utf-8");
function json_response($data, $ok = true) { echo json_encode(['ok' => $ok, 'data' => $data]); exit; }
function json_error($message) { echo json_encode(['ok' => false, 'error' => $message]); exit; }
$action = $_REQUEST['action'] ?? null;
$body = json_decode(file_get_contents('php://input'), true);

// --- LIST (GET) ACTIONS ---
if ($action === 'list_genres') {
    $result = $mysqli->query("SELECT * FROM genres ORDER BY genre_name");
    json_response($result->fetch_all(MYSQLI_ASSOC));
}
if ($action === 'list_shows') {
    $result = $mysqli->query("SELECT * FROM shows ORDER BY title");
    $shows = $result->fetch_all(MYSQLI_ASSOC);
    $stmt_genre = $mysqli->prepare("SELECT g.genre_id, g.genre_name FROM show_genres sg JOIN genres g ON sg.genre_id = g.genre_id WHERE sg.show_id = ?");
    foreach ($shows as &$show) {
        $stmt_genre->bind_param("i", $show["show_id"]);
        $stmt_genre->execute();
        $show["genres"] = $stmt_genre->get_result()->fetch_all(MYSQLI_ASSOC);
    }
    json_response($shows);
}
if ($action === 'list_performances') {
    $result = $mysqli->query("SELECT * FROM performances ORDER BY performance_date, start_time");
    json_response($result->fetch_all(MYSQLI_ASSOC));
}
if ($action === 'list_theaters') {
    $result = $mysqli->query("SELECT * FROM theaters ORDER BY name");
    json_response($result->fetch_all(MYSQLI_ASSOC));
}
if ($action === 'get_seat_map' && isset($_GET['id'])) {
    $theaterId = intval($_GET['id']);
    $theater = $mysqli->query("SELECT * FROM theaters WHERE theater_id = $theaterId")->fetch_assoc();
    $seats = $mysqli->query("SELECT s.*, sc.color_class FROM seats s JOIN seat_categories sc ON s.category_id = sc.category_id WHERE s.theater_id = $theaterId")->fetch_all(MYSQLI_ASSOC);
    if(!$theater || !$seats) { json_error('Could not find theater or seat data.'); }
    json_response(['theater' => $theater, 'seats' => $seats]);
}
if ($action === 'get_performance_details' && isset($_GET['id'])) {
    $perfId = intval($_GET['id']);
    $perf = $mysqli->query("SELECT p.*, s.title, t.name AS theater_name FROM performances p JOIN shows s ON p.show_id = s.show_id JOIN theaters t ON p.theater_id = t.theater_id WHERE p.performance_id = $perfId")->fetch_assoc();
    if(!$perf) { json_error('Performance not found'); }
    $theaterId = $perf['theater_id'];
    $seats = $mysqli->query("SELECT s.*, sc.color_class FROM seats s JOIN seat_categories sc ON s.category_id = sc.category_id WHERE s.theater_id = $theaterId")->fetch_all(MYSQLI_ASSOC);
    $booked_seats_result = $mysqli->query("SELECT t.seat_id FROM tickets t JOIN bookings b ON t.booking_id = b.booking_id WHERE b.performance_id = $perfId AND b.booking_status != 'cancelled'");
    $booked_seat_ids = array_column($booked_seats_result->fetch_all(MYSQLI_ASSOC), 'seat_id');
    json_response(['performance' => $perf, 'theater' => ['theater_id' => $theaterId, 'name' => $perf['theater_name']], 'seats' => $seats, 'booked_seat_ids' => $booked_seat_ids]);
}

// --- MODIFY (POST) ACTIONS ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $body) {
    if ($action === 'save_show') {
        $id = !empty($body["show_id"]) ? intval($body["show_id"]) : 0;
        $mysqli->begin_transaction();
        try {
            if ($id > 0) { $stmt = $mysqli->prepare("UPDATE shows SET title=?, description=?, duration_minutes=?, director=?, poster_image_url=? WHERE show_id=?"); $stmt->bind_param("ssissi", $body["title"], $body["description"], $body["duration_minutes"], $body["director"], $body["poster_image_url"], $id); } 
            else { $stmt = $mysqli->prepare("INSERT INTO shows (title, description, duration_minutes, director, poster_image_url) VALUES (?, ?, ?, ?, ?)"); $stmt->bind_param("ssiss", $body["title"], $body["description"], $body["duration_minutes"], $body["director"], $body["poster_image_url"]); }
            $stmt->execute();
            $new_id = $id > 0 ? $id : $mysqli->insert_id;
            $mysqli->query("DELETE FROM show_genres WHERE show_id = $new_id");
            if (!empty($body["genre_ids"])) {
                $stmt_genre = $mysqli->prepare("INSERT INTO show_genres (show_id, genre_id) VALUES (?, ?)");
                foreach ($body["genre_ids"] as $gid) { $stmt_genre->bind_param("ii", $new_id, $gid); $stmt_genre->execute(); }
            }
            $mysqli->commit(); json_response(null);
        } catch (Exception $e) { $mysqli->rollback(); json_error($e->getMessage()); }
    }
    if ($action === 'delete_show') {
        $id = intval($body['show_id'] ?? 0);
        $mysqli->begin_transaction();
        try {
            $mysqli->query("DELETE FROM show_genres WHERE show_id = $id");
            $mysqli->query("DELETE FROM performances WHERE show_id = $id");
            $stmt = $mysqli->prepare("DELETE FROM shows WHERE show_id = ?"); $stmt->bind_param("i", $id); $stmt->execute();
            $mysqli->commit(); json_response(null);
        } catch (Exception $e) { $mysqli->rollback(); json_error($e->getMessage()); }
    }
    if ($action === 'save_performance') {
        $stmt = $mysqli->prepare("INSERT INTO performances (show_id, theater_id, performance_date, start_time, price) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("iisss", $body["show_id"], $body["theater_id"], $body["performance_date"], $body["start_time"], $body["price"]);
        $stmt->execute(); json_response(null);
    }
    if ($action === 'delete_performance') {
        $stmt = $mysqli->prepare("DELETE FROM performances WHERE performance_id = ?"); $stmt->bind_param("i", $body['performance_id']);
        $stmt->execute(); json_response(null);
    }
    if ($action === 'create_theater') {
        $stmt = $mysqli->prepare("INSERT INTO theaters (name) VALUES (?)"); $stmt->bind_param("s", $body['name']); $stmt->execute();
        $theaterId = $mysqli->insert_id;
        $stmt_seat = $mysqli->prepare("INSERT INTO seats (theater_id, row_char, seat_number, category_id) VALUES (?, ?, ?, ?)");
        for ($r = 0; $r < $body['rows']; $r++) {
            for ($c = 1; $c <= $body['cols']; $c++) {
                $rowChar = chr(65 + $r); $catId = ($r < floor($body['rows'] / 3)) ? 1 : (($r < floor($body['rows'] * 2 / 3)) ? 2 : 3);
                $stmt_seat->bind_param("isii", $theaterId, $rowChar, $c, $catId); $stmt_seat->execute();
            }
        }
        json_response(null);
    }
    if ($action === 'update_seat_category') {
        $seatId = intval($body['seat_id']);
        $mysqli->query("UPDATE seats SET category_id = ( (category_id % 3) + 1 ) WHERE seat_id = $seatId");
        json_response(null);
    }
    if ($action === 'save_genre') {
        $id = !empty($body["genre_id"]) ? intval($body["genre_id"]) : 0;
        if ($id > 0) {
            $stmt = $mysqli->prepare("UPDATE genres SET genre_name=? WHERE genre_id=?");
            $stmt->bind_param("si", $body["genre_name"], $id);
        } else {
            $stmt = $mysqli->prepare("INSERT INTO genres (genre_name) VALUES (?)");
            $stmt->bind_param("s", $body["genre_name"]);
        }
        $stmt->execute();
        json_response(null);
    }
    if ($action === 'delete_genre') {
        $id = intval($body['genre_id'] ?? 0);
        $mysqli->begin_transaction();
        try {
            $mysqli->query("DELETE FROM show_genres WHERE genre_id = $id");
            $stmt = $mysqli->prepare("DELETE FROM genres WHERE genre_id = ?");
            $stmt->bind_param("i", $id);
            $stmt->execute();
            $mysqli->commit();
            json_response(null);
        } catch (Exception $e) {
            $mysqli->rollback();
            json_error($e->getMessage());
        }
    }
}

json_error("Invalid API Action: " . ($action ?? 'none'));
?>